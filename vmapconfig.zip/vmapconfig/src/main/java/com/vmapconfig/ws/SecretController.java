package com.vmapconfig.ws;

public class SecretController {

}
