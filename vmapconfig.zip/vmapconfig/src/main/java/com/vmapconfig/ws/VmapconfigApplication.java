package com.vmapconfig.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VmapconfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(VmapconfigApplication.class, args);
	}

}
