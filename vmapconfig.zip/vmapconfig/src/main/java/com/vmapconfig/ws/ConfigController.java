package com.vmapconfig.ws;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("config")
public class ConfigController {
	
	@GetMapping
	public String getConfig() {
		
		int i = 0;
		for(i=0; i<=3; i++) {
			i += i;
		}
		return "getConfig was called"+i;
	}
	
	@PostMapping
	public String createConfig() {
		return "postConfig was called";
	}
}
